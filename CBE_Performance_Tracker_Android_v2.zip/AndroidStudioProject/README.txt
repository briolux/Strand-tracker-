NATIVE ANDROID APP PROJECT
This is an Android Studio project containing the tracker as an embedded WebView.
It is designed to compile into a real APK, so the final app does not require Chrome.
Open the AndroidStudioProject folder in Android Studio and Build > Build APK(s).

The included HTML is also provided separately for quick browser testing.

Important curriculum note:
The subject catalogue is aligned to KICD Grade 10 learning-area listings. The app provides a Curriculum Manager so exact KICD strands/sub-strands can be loaded without inventing curriculum content. The official KICD Grade 10 design portal is the source of truth for the designs.
